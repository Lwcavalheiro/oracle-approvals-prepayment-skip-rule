# Screenshots

## bpm-assignees-skip-rule-config.png

Oracle BPM Worklist – Invoice Approval Task configuration screen showing:

- **Assignees tab** with the parallel workflow diagram
- The `SoaOLabel.InvoiceApproversParallelParticipantinPar` participant selected
- **Advanced tab** open at the bottom panel
- **Specify skip rule** checkbox enabled
- The `orcl:query-database(concat('SI...` expression visible in the skip rule field
